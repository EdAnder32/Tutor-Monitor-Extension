/**
 * 42 Tutor Badge → Dashboard redirect
 * Runs on https://profile.intra.42.fr/*
 *
 * Finds every .user-badge[data-badge="tutor"] element,
 * wraps it in an <a> tag, and styles it so it looks
 * interactive without breaking the existing badge appearance.
 */

const DASHBOARD_URL = "http://localhost:8080/dashboard";

function patchTutorBadges() {
  const badges = document.querySelectorAll(
    '.user-badge[data-badge="tutor"]:not([data-tutor-patched])'
  );

  badges.forEach((badge) => {
    // Mark as already processed so we don't double-wrap on re-runs
    badge.setAttribute("data-tutor-patched", "true");

    // Build the anchor
    const link = document.createElement("a");
    link.href = DASHBOARD_URL;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.title = "Abrir dashboard do Tutor";

    // Cursor + subtle hover ring without touching the badge's own styles
    link.style.cssText = `
      display: inline-block;
      cursor: pointer;
      border-radius: inherit;
      text-decoration: none;
      outline: none;
      transition: filter 0.15s ease, transform 0.15s ease;
    `;

    link.addEventListener("mouseenter", () => {
      link.style.filter = "brightness(1.25) drop-shadow(0 0 6px #9B59B6)";
      link.style.transform = "scale(1.05)";
    });
    link.addEventListener("mouseleave", () => {
      link.style.filter = "";
      link.style.transform = "";
    });

    // Wrap: insert link before badge in the DOM, then move badge inside
    badge.parentNode.insertBefore(link, badge);
    link.appendChild(badge);
  });
}

// Run immediately on static pages
patchTutorBadges();

// Re-run whenever the DOM changes (42 intra is a SPA / loads content dynamically)
const observer = new MutationObserver(() => patchTutorBadges());
observer.observe(document.body, { childList: true, subtree: true });
